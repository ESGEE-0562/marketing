# Eltee Sydney Project Context

This plugin has been customised for **Eltee Sydney**, an Australian activewear brand making performance periodwear for active girls.

All skills in this plugin should treat Eltee Sydney as the default subject unless the user names a different project or brand.

## The eltee-brand skill is canonical

The `eltee-brand` skill is the source of truth for the brand. Read it in full at the start of any content task. Do not duplicate or rewrite anything that lives there. This file only adds marketing-specific operating context on top of it.

If something looks contradictory between this file and `eltee-brand`, `eltee-brand` wins.

## Brand in one line

Period underwear for tween and teen girls. Designed for sport and active life. Not here to empower. Here to equip.

## Products (full list lives in eltee-brand)

UnderSwim OG, UnderSwim G-Fit, UnderAustin, UnderDance, Bumpers Briefs, UnderShortie, SwimSync Period Pro, Period Swim Bikini Bottom, UnderLiner. Bumpers is Eltee's proprietary side-leak barrier technology, used as both a product name and a feature name.

## Audiences

Two real audiences. Speak to both, but never as one blended persona.

1. **Girls** (tween and teen). She is the wearer. Keep it natural, light, unembarrassing. Avoid talking down or motivational language. Make the product feel normal, useful, wearable.
2. **Mums**. She is the buyer. Lead with trust, function, reliability, fit. Show you understand the real-world problem without becoming sentimental. Reassure through specifics.

For mixed audiences, balance trust signals for mums with wearability and relevance for girls. Do not write copy that only works for one side.

## Partnerships and proof points

- **Swimming Australia**: official partnership. UnderSwim is Swimming Australia's endorsed period-safe swim underwear. This is a real, citable trust signal. Do not overuse, but absolutely use it where relevant.
- **Kiera "Kip" Austin**: netballer and UnderAustin co-designer.
- Confirmed stat: 63.9% of Australian girls aged 11 to 16 have skipped or quit sport due to their period (source via eltee-brand skill).
- Sport-specific skip rates: Swimming 67.6%, Gymnastics 35.1%, Dancing 28.4%, Netball 25%.

Do not invent additional stats, percentages, or endorsements. Do not extrapolate beyond what is in the eltee-brand skill.

## Channels

Eltee runs across:

- Email (Klaviyo)
- Instagram (organic and paid)
- Facebook (organic and paid)
- TikTok
- Paid search (Google Ads)
- Influencer and partner activations
- SEO and blog
- In-store and events
- PR

For any campaign or piece of content, default to picking the right channel and tone for the job. Treat Instagram and Email as primary owned channels.

## Stack

| Function | Tool |
|---|---|
| Email and SMS | Klaviyo |
| Ecommerce | Shopify |
| Design | Canva |
| Brand and reference docs | Google Drive |
| SEO and competitor research | Serpstat |
| Paid media | Meta Ads, Google Ads, TikTok |
| Cross-platform reporting | Supermetrics (when needed) |
| Creative analytics | Motion (Motion App), authenticated to the Elteesydney workspace |


## Motion is the default creative analytics source

Motion (Motion App) is connected to the Eltee Sydney organisation and the Elteesydney workspace. When a task touches creative performance, ad copy patterns, demographic response, or competitor creative, reach for Motion first. Web research is a supplement, not the primary source.

When asked to pull or analyse creative performance, default to:
- Motion creative insights and summaries for Eltee's own ads
- Motion demographic breakdowns to find which audiences each creative is reaching
- Motion brand and competitor creative for periodwear and adjacent activewear (Modibodi, Knix, ThinX, Bonds, Lululemon active)
- Motion inspo creatives where Sarah wants to look outside the category
- Motion saved reports if relevant work has already been done

## Output style rules

These are hard rules from the eltee-brand skill. Repeated here for prominence:

- No em dashes. Ever. Use commas, full stops, parentheses, or rewrite
- No italics with Poppins or Chunk Five. No italics in body copy
- Sentences short and active. Plain natural language. Never over-explain
- Use "Hello" not "Hi" in email greetings
- No bullet points, bold headers, or lists in conversational responses (this rule is for chat replies, not for content artefacts where lists are appropriate, like product pages and emails)
- Australian English spelling and idiom

## Banned phrasing (from eltee-brand)

Never use:

- "even on her period", "even during her period"
- Any framing that treats menstruation as an abnormal obstacle or dramatic exception
- Empty hype claims
- Invented statistics
- Claims that imply universal outcomes

Avoid unless the brief explicitly requires:

- empower, empowering, shine, fearless, girl boss, magic, revolutionise
- game-changing (unless truly warranted and supported)
- every girl (unless factually appropriate)
- guarantees (unless explicitly supported)
- life-changing (unless quoting a customer directly and accurately)
- gear

Use with care: confidence, support (only when grounded in product function or lived experience).

## Claim guardrails

- Do not invent product features, endorsements, certifications, or performance claims
- Do not hallucinate survey findings, percentages, or customer feedback
- Only use product-specific claims clearly supported by eltee-brand or the brief
- Prefer "designed to", "made to", "helps", or "gives" over absolute promises when certainty is not supported
- If evidence is limited, keep copy tighter and more observational

## What success looks like for outputs

- Sound unmistakably like Eltee Sydney
- Useful before clever
- Persuasive without inflated
- Practical and grounded
- Mum trusts the product. Girl wants to wear it.

## Working folder

Final deliverables save to whichever Cowork folder Sarah selects for the task. If unsure, ask. Do not assume.
