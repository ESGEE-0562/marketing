# Connectors

This plugin has been customised for **Eltee Sydney**, a DTC periodwear brand. The stack reflects an established ecommerce business running paid media, email, and influencer activations.

## Tools used by this plugin

| Category | Tool | Status | Notes |
|----------|------|--------|-------|
| Chat | Slack | Connected | Internal team comms and shared drafts |
| Email and SMS | Klaviyo | Connected | Primary marketing automation. Use for flows, campaigns, segments, lists, and reporting |
| Ecommerce | Shopify | Connected separately | Source of truth for products, customers, orders, inventory |
| Design | Canva | Connected | Asset production for organic social, email, and ads |
| Brand and reference docs | Google Drive | Connected separately | Brand guidelines, briefs, campaign documents, asset libraries |
| SEO and competitor research | Serpstat | Connected separately | Keyword research, ranking, competitor visibility |
| Cross-platform paid analytics | Supermetrics | Available | Pulls from Meta Ads, Google Ads, TikTok Ads when needed |
| Creative analytics | Motion (Motion App) | Connected separately, authenticated to the Elteesydney workspace | Creative performance, ad transcripts, demographic breakdown, competitor creative context, inspo creatives |
| Calendar | Google Calendar | Connected | Campaign and content scheduling |
| Email | Gmail | Connected | Stakeholder, partnership and PR comms |

## Tools the brand uses but not via this plugin's MCP

These are part of Sarah's broader Eltee stack. The plugin assumes she works in them directly when needed:

- Meta Ads Manager (Instagram, Facebook)
- Google Ads
- TikTok Ads
- Shopify admin
- Google Drive (for brand reference)
- Serpstat dashboard (for SEO)

## How to use placeholders inside skills

Generic skill text may still reference categories like "marketing automation" or "email marketing". For Eltee, treat those as Klaviyo unless Sarah specifies otherwise.

If a skill references SaaS-style tools that are not part of the Eltee stack (HubSpot, Amplitude, Marketo, Customer.io), substitute the equivalent: Klaviyo for email and lifecycle, Shopify analytics for product behaviour, Supermetrics for cross-channel paid reporting.

## When data is missing

If a skill calls for data that is not actually available (paid spend not yet pulled, segment not yet built, campaign not yet run), do not fabricate it. Tell Sarah what is missing and offer to draft the framework or template that the data will fill once available.

## Motion (Motion App) specifics

Motion is connected at the workspace level (Eltee Sydney organisation, "Elteesydney" workspace) and accessible to Claude across this Cowork project. Use it whenever creative performance is in scope.

What Motion is good for:

- Pulling creative insights for Eltee's own ads (which Reels, statics, or videos are working, why)
- Reading ad transcripts and creative summaries to spot patterns in copy and hook structure
- Demographic breakdowns by creative
- Competitor creative context (Modibodi, Knix, ThinX, Bonds, Lululemon active, and any other brand searched)
- Inspo creatives from outside the periodwear category
- Saved Motion reports

Skills that should reach for Motion first:

- `/performance-report`: pull creative read-outs and demographic splits to back the channel report
- `/competitive-brief`: pull competitor creative samples plus brand context rather than relying only on web research
- `/campaign-plan`: validate creative direction with Motion patterns from past Eltee performance
- `/draft-content`: when drafting a new ad or Reel, ground the brief in what is currently working in Motion
- `/brand-review`: check the proposed creative against the patterns of high-performing Eltee work
