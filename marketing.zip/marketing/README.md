# marketing

A customised build of the Marketing plugin for **Eltee Sydney**, an Australian periodwear brand for active girls.

The canonical brand reference is the `eltee-brand` skill (already installed in this workspace). This plugin's [ELTEE.md](ELTEE.md) adds marketing-specific operating context. [CONNECTORS.md](CONNECTORS.md) lists the Eltee stack.

Every skill in this plugin loads ELTEE.md and defers to the eltee-brand skill before producing any content.

## Skills

| Command | What it does for Eltee |
|---|---|
| `/competitive-brief` | Researches periodwear and adjacent activewear competitors. Maps positioning across the period and active categories. Default output is a positioning and message comparison, not a sales battlecard. |
| `/campaign-plan` | Builds DTC campaign briefs for product launches, seasonal pushes, partnership activations, and retention plays. Audience splits into girls and mums. Channel defaults to Klaviyo, Instagram, and paid social before reaching for SaaS-style tactics. |
| `/brand-review` | Auto-flags banned phrasing, em dashes, italics, empowerment cliches, "even on her period" framing, unsubstantiated stats, and any claim that drifts from the eltee-brand reference. |
| `/draft-content` | Produces channel-specific Eltee copy: product page sections, ads, social captions, Reel and TikTok scripts, founder posts, customer care responses, partner announcements. |
| `/email-sequence` | Builds Klaviyo flows: welcome, abandoned cart, post-purchase, win-back, education series, and partnership-specific drops. Two-audience aware (the girl is the wearer, the mum is often the buyer and recipient). |
| `/performance-report` | Eltee performance reads pulling from Klaviyo, Shopify, Meta Ads, Google Ads, TikTok and Supermetrics. Default metrics are DTC: AOV, conversion rate, CAC, ROAS, repeat rate, list growth, and contribution by channel. |
| `/seo-audit` | SEO and content gap research for the Eltee site. Periodwear, period-safe swim, period-safe sport, and audience-led queries (mum search vs girl search). Pulls from Serpstat where available. |

## Working folders

This Cowork workspace mounts:

- Project folders Sarah selects per task (currently set up around the `BTC` brief, but Eltee work can use any folder)
- The `eltee-brand` skill, which is the source of truth for products, voice, terminology, and proof points

## MCP servers in this build

| Tool | Used for |
|---|---|
| Slack | Sharing drafts and briefs |
| Klaviyo | Email and SMS flows, campaigns, segments, reporting |
| Canva | Design asset production |
| Motion (Motion App) | Creative analytics, ad performance, demographic breakdown, competitor creative |
| Supermetrics | Cross-platform paid media reporting |
| Google Calendar | Campaign scheduling |
| Gmail | Stakeholder, partnership and PR comms |

Removed from the generic build because they are not Eltee's stack: HubSpot, Amplitude, Notion, Figma, Ahrefs, Similarweb. Shopify, Google Drive, and Serpstat are connected outside this plugin.

## How to extend or change this build

- Update [ELTEE.md](ELTEE.md) for project-wide operating context and rules. Every skill loads it
- Update [CONNECTORS.md](CONNECTORS.md) when a tool changes
- Each skill has an `Eltee default workflow` section near the top. Edit there to change skill-specific behaviour without touching the underlying generic process
- The `eltee-brand` skill is the canonical brand reference. Do not duplicate its content here. Update it directly when products, voice, or proof points change
